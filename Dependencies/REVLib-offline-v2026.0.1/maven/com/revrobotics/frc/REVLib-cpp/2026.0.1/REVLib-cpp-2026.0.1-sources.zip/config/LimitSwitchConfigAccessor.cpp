/*
 * Copyright (c) 2024-2025 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/config/LimitSwitchConfigAccessor.h"

#include <stdint.h>

#include "rev/CANSparkDriver.h"

using namespace rev::spark;

LimitSwitchConfigAccessor::LimitSwitchConfigAccessor(void* sparkHandle)
    : m_sparkHandle(sparkHandle) {}

bool LimitSwitchConfigAccessor::GetForwardLimitSwitchEnabled() const {
    uint32_t value;
    c_Spark_GetParameterUint32(static_cast<c_Spark_handle>(m_sparkHandle),
                               c_Spark_kHardLimitFwdEn, &value);
    return (value == LimitSwitchConfig::Behavior::kStopMovingMotor) ||
           (value ==
            LimitSwitchConfig::Behavior::kStopMovingMotorAndSetPosition);
}

LimitSwitchConfig::Behavior
LimitSwitchConfigAccessor::GetForwardLimitSwitchTriggerBehavior() const {
    uint32_t value;
    c_Spark_GetParameterUint32(static_cast<c_Spark_handle>(m_sparkHandle),
                               c_Spark_kHardLimitFwdEn, &value);
    return static_cast<LimitSwitchConfig::Behavior>(value);
}

LimitSwitchConfig::Type LimitSwitchConfigAccessor::GetForwardSwitchType()
    const {
    uint8_t value;
    c_Spark_GetParameterBool(static_cast<c_Spark_handle>(m_sparkHandle),
                             c_Spark_kLimitSwitchFwdPolarity, &value);
    return value != 0 ? LimitSwitchConfig::Type::kNormallyClosed
                      : LimitSwitchConfig::Type::kNormallyOpen;
}

double LimitSwitchConfigAccessor::GetForwardLimitSwitchPosition() const {
    float value;
    c_Spark_GetParameterFloat32(static_cast<c_Spark_handle>(m_sparkHandle),
                                c_Spark_kLimitSwitchFwdPosition, &value);
    return value;
}

bool LimitSwitchConfigAccessor::GetReverseLimitSwitchEnabled() const {
    uint32_t value;
    c_Spark_GetParameterUint32(static_cast<c_Spark_handle>(m_sparkHandle),
                               c_Spark_kHardLimitRevEn, &value);
    return (value == LimitSwitchConfig::Behavior::kStopMovingMotor) ||
           (value ==
            LimitSwitchConfig::Behavior::kStopMovingMotorAndSetPosition);
}

LimitSwitchConfig::Behavior
LimitSwitchConfigAccessor::GetReverseLimitSwitchTriggerBehavior() const {
    uint32_t value;
    c_Spark_GetParameterUint32(static_cast<c_Spark_handle>(m_sparkHandle),
                               c_Spark_kHardLimitRevEn, &value);
    return static_cast<LimitSwitchConfig::Behavior>(value);
}

LimitSwitchConfig::Type LimitSwitchConfigAccessor::GetReverseSwitchType()
    const {
    uint8_t value;
    c_Spark_GetParameterBool(static_cast<c_Spark_handle>(m_sparkHandle),
                             c_Spark_kLimitSwitchRevPolarity, &value);
    return value != 0 ? LimitSwitchConfig::Type::kNormallyClosed
                      : LimitSwitchConfig::Type::kNormallyOpen;
}

double LimitSwitchConfigAccessor::GetReverseLimitSwitchPosition() const {
    float value;
    c_Spark_GetParameterFloat32(static_cast<c_Spark_handle>(m_sparkHandle),
                                c_Spark_kLimitSwitchRevPosition, &value);
    return value;
}
