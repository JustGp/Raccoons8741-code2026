/*
 * Copyright (c) 2024-2025 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/config/EncoderConfig.h"

#include "rev/config/SparkParameters.h"

using namespace rev::spark;

EncoderConfig& EncoderConfig::Apply(EncoderConfig& config) {
    BaseConfig::Apply(config);
    return *this;
}

EncoderConfig& EncoderConfig::CountsPerRevolution(int cpr) {
    PutParameter(SparkParameter::kEncoderCountsPerRev,
                 static_cast<uint32_t>(cpr));
    return *this;
}

EncoderConfig& EncoderConfig::Inverted(bool inverted) {
    PutParameter(SparkParameter::kEncoderInverted, inverted);
    return *this;
}

EncoderConfig& EncoderConfig::PositionConversionFactor(double factor) {
    PutParameter(SparkParameter::kPositionConversionFactor,
                 static_cast<float>(factor));
    return *this;
}

EncoderConfig& EncoderConfig::VelocityConversionFactor(double factor) {
    PutParameter(SparkParameter::kVelocityConversionFactor,
                 static_cast<float>(factor));
    return *this;
}

EncoderConfig& EncoderConfig::QuadratureAverageDepth(int depth) {
    PutParameter(SparkParameter::kEncoderAverageDepth,
                 static_cast<uint32_t>(depth));
    return *this;
}

EncoderConfig& EncoderConfig::QuadratureMeasurementPeriod(int periodMs) {
    PutParameter(SparkParameter::kEncoderSampleDelta,
                 static_cast<uint32_t>(periodMs) << 1);
    return *this;
}

EncoderConfig& EncoderConfig::UvwAverageDepth(int depth) {
    uint32_t depthIndex;
    switch (depth) {
        case (1):
            depthIndex = 0;
            break;
        case (2):
            depthIndex = 1;
            break;
        case (4):
            depthIndex = 2;
            break;
        default:
            depthIndex = 3;
    }

    PutParameter(SparkParameter::kUvwSensorAverageDepth, depthIndex);
    return *this;
}

EncoderConfig& EncoderConfig::UvwMeasurementPeriod(int periodMs) {
    // Convert from period (ms) to native units (seconds)
    const double rate = static_cast<double>(periodMs) / 1000.;
    PutParameter(SparkParameter::kUvwSensorSampleRate,
                 static_cast<float>(rate));
    return *this;
}
